/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['DM Sans', 'sans-serif'], display: ['Manrope', 'sans-serif'] },
      colors: { ink: '#17231f', muted: '#718078', forest: '#174b3b', mint: '#dff0e7', cream: '#f7f8f6', coral: '#f28d70' },
      boxShadow: { soft: '0 18px 60px rgba(23,35,31,.08)' }
    }
  },
  plugins: []
}
