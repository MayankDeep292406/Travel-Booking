import { useEffect, useState } from 'react'
import { Link, NavLink, Route, Routes, useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, ArrowUpRight, CalendarDays, Check, ChevronDown, Compass, Globe2, Heart, MapPin, Menu, Plane, Search, ShieldCheck, Sparkles, Star, Users, X } from 'lucide-react'
import api from './api'
import { destinations as demoDestinations } from './data'

function Header() {
  const [open, setOpen] = useState(false)
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('travel_user') || 'null'))
  useEffect(() => {
    const sync = () => setUser(JSON.parse(localStorage.getItem('travel_user') || 'null'))
    window.addEventListener('storage', sync)
    return () => window.removeEventListener('storage', sync)
  }, [])
  const logout = () => { localStorage.removeItem('travel_token'); localStorage.removeItem('travel_user'); setUser(null); window.location.href = '/' }
  const nav = <><NavLink to="/destinations" onClick={() => setOpen(false)}>Destinations</NavLink><a href="/#why" onClick={() => setOpen(false)}>Why us</a><a href="/#stories" onClick={() => setOpen(false)}>Our stories</a></>
  return <header className="site-header"><div className="container nav-wrap">
    <Link to="/" className="brand"><span className="brand-mark"><Compass size={19}/></span><span>Travel Booking<span className="brand-dot">.</span></span></Link>
    <nav className="desktop-nav">{nav}</nav>
    <div className="nav-actions"><Link to={user ? '/bookings' : '/login'} className="nav-login">{user ? 'My trips' : 'Log in'}</Link>{user ? <button className="nav-cta" onClick={logout}>Log out</button> : <Link className="nav-cta" to="/register">Sign up <ArrowUpRight size={15}/></Link>}</div>
    <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
  </div>{open && <div className="mobile-nav">{nav}<Link to="/login">Log in</Link><Link to="/register">Sign up</Link></div>}</header>
}

function Footer() {
  return <footer className="footer"><div className="container footer-top"><div><Link to="/" className="brand footer-brand"><span className="brand-mark"><Compass size={19}/></span><span>Travel Booking<span className="brand-dot">.</span></span></Link><p>Go beyond the ordinary.<br/>Find a little more somewhere.</p></div><div className="footer-links"><div><b>Explore</b><Link to="/destinations">Destinations</Link><a href="/#why">Why somewhere</a><a href="/#stories">Travel journal</a></div><div><b>Support</b><a href="mailto:hello@somewhere.travel">Contact us</a><a href="mailto:hello@somewhere.travel">FAQs</a><Link to="/bookings">My bookings</Link></div></div></div><div className="container footer-bottom"><span>© 2026 Somewhere Travel. Made for curious souls.</span><span>Thoughtful journeys, beautifully found.</span></div></footer>
}

function SearchPanel() {
  const [where,setWhere] = useState('')
  const [date,setDate] = useState('')
  const [travelers,setTravelers] = useState('2 travelers')
  const go = () => window.location.href = `/destinations${where ? `?search=${encodeURIComponent(where)}` : ''}`
  return <div className="search-panel">
    <label className="search-field"><span className="field-icon"><MapPin size={18}/></span><span><small>Where to?</small><input value={where} onChange={e=>setWhere(e.target.value)} placeholder="Explore destinations"/></span></label>
    <label className="search-field"><span className="field-icon"><CalendarDays size={18}/></span><span><small>When?</small><input type="date" value={date} onChange={e=>setDate(e.target.value)} /></span></label>
    <label className="search-field"><span className="field-icon"><Users size={18}/></span><span><small>Who’s going?</small><select value={travelers} onChange={e=>setTravelers(e.target.value)}><option>1 traveler</option><option>2 travelers</option><option>3 travelers</option><option>4+ travelers</option></select></span></label>
    <button className="search-button" onClick={go}><Search size={18}/> <span>Find a trip</span></button>
  </div>
}

function DestinationCard({ item, index=0 }) {
  return <Link to={`/destinations/${item._id}`} className={`destination-card ${index===0?'featured-card':''}`}>
    <div className="destination-image"><img src={item.image} alt={`${item.name}, ${item.country}`} loading="lazy"/><span className="image-tag">{item.category}</span><button className="heart-btn" onClick={e=>{e.preventDefault();e.currentTarget.classList.toggle('liked')}} aria-label="Save destination"><Heart size={17}/></button></div>
    <div className="destination-info"><div><h3>{item.name}</h3><p><MapPin size={13}/> {item.country}</p></div><div className="rating"><Star size={14} fill="currentColor"/> {item.rating}</div></div>
    <div className="destination-meta"><span>{item.days} days · curated stay</span><span>From <b>${item.price.toLocaleString()}</b></span></div>
  </Link>
}

function Home() {
  const [items,setItems] = useState(demoDestinations)
  useEffect(()=>{api.get('/destinations').then(r=>{if(r.data?.length)setItems(r.data)}).catch(()=>{})},[])
  return <>
    <section className="hero"><div className="hero-bg"></div><div className="container hero-content"><div className="eyebrow light"><span></span> YOUR NEXT CHAPTER STARTS HERE</div><h1>Find your<br/><em>somewhere.</em></h1><p className="hero-copy">The world is full of places that will stay with you.<br className="desktop-only"/> Let's find the one that feels like yours.</p><a href="#discover" className="hero-link">Explore our journeys <ArrowRight size={16}/></a></div><div className="hero-note"><span>01 / 06</span><span>Curated journeys. Unforgettable stories.</span></div></section>
    <section className="search-section container"><SearchPanel/></section>
    <section className="section container" id="discover"><div className="section-heading"><div><div className="eyebrow"><span></span> THE WORLD, WELL DISCOVERED</div><h2>Places worth<br/><em>getting lost in.</em></h2></div><Link to="/destinations" className="text-link">View all destinations <ArrowUpRight size={16}/></Link></div>
      <div className="destination-grid">{items.slice(0,3).map((d,i)=><DestinationCard item={d} index={i} key={d._id}/>)}</div>
    </section>
    <section className="quote-band"><div className="container quote-inner"><Sparkles size={22}/><p>“We travel not to escape life, but for life not to escape us.”</p><span>— ROBYN YOUNG</span></div></section>
    <section className="section container" id="why"><div className="section-heading centered"><div className="eyebrow"><span></span> A DIFFERENT WAY TO GET THERE</div><h2>Travel, with a little<br/><em>more meaning.</em></h2><p className="section-intro">The best trips aren't just about where you go. They're about how you feel along the way.</p></div>
      <div className="perks-grid"><div className="perk"><span><Compass/></span><h3>Thoughtfully curated</h3><p>Handpicked stays and local experiences, chosen for the feeling they leave behind.</p></div><div className="perk"><span><ShieldCheck/></span><h3>Peace of mind</h3><p>Clear pricing, trusted partners and real humans ready to help when you need us.</p></div><div className="perk"><span><Globe2/></span><h3>Closer to local</h3><p>Go beyond the usual highlights and discover the soul of every destination.</p></div></div>
    </section>
    <section className="newsletter"><div className="container newsletter-inner"><div><div className="eyebrow light"><span></span> A NOTE FROM SOMEWHERE</div><h2>A little wanderlust<br/>in your inbox.</h2><p>Beautiful places, thoughtful tips and stories worth opening.</p></div><Newsletter/></div></section>
    <Footer/>
  </>
}

function Newsletter() {
  const [email,setEmail] = useState('')
  const [done,setDone] = useState(false)
  return <form className="newsletter-form" onSubmit={e=>{e.preventDefault();setDone(true)}}><label htmlFor="newsletter-email">Your email address</label><div><input id="newsletter-email" type="email" required placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/><button aria-label="Subscribe"><ArrowRight/></button></div><small>{done ? 'You’re on the list. Keep an eye on your inbox!' : 'No noise. Just the good stuff, once in a while.'}</small></form>
}

function Destinations() {
  const [items,setItems] = useState(demoDestinations)
  const [search,setSearch] = useState(new URLSearchParams(location.search).get('search') || '')
  useEffect(()=>{api.get('/destinations').then(r=>{if(r.data?.length)setItems(r.data)}).catch(()=>{})},[])
  const filtered=items.filter(d=>`${d.name} ${d.country} ${d.category}`.toLowerCase().includes(search.toLowerCase()))
  return <><main className="page-main"><div className="container"><div className="eyebrow"><span></span> FIND YOUR NEXT SOMEWHERE</div><h1 className="page-title">The world is<br/><em>wide open.</em></h1><p className="page-lead">A collection of places we'd go back to in a heartbeat.</p><div className="listing-search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search places, countries or experiences..."/></div><div className="destination-grid listing-grid">{filtered.map((d,i)=><DestinationCard key={d._id} item={d} index={i}/>)}</div>{!filtered.length&&<p className="empty-state">No destinations found. Try another search.</p>}</div></main><Footer/></>
}

function DestinationDetail() {
  const {id}=useParams()
  const [item,setItem]=useState(demoDestinations.find(d=>d._id===id))
  useEffect(()=>{api.get(`/destinations/${id}`).then(r=>setItem(r.data)).catch(()=>{})},[id])
  if(!item) return <main className="page-main container"><h1>Destination not found</h1><Link to="/destinations">Back to destinations</Link></main>
  return <><main className="detail-page"><div className="container"><Link to="/destinations" className="back-link">← All destinations</Link><div className="detail-hero"><img src={item.image} alt={item.name}/><div className="detail-overlay"><span>{item.category}</span><h1>{item.name}</h1><p><MapPin size={16}/> {item.country}</p></div></div><div className="detail-columns"><div><div className="eyebrow"><span></span> THE FEELING OF {item.name.toUpperCase()}</div><h2>Somewhere<br/><em>to remember.</em></h2><p className="detail-description">{item.description}</p><div className="detail-facts"><span><Star size={16}/> {item.rating} guest rating</span><span><CalendarDays size={16}/> {item.days} days</span><span><Plane size={16}/> Curated itinerary</span></div></div><BookingCard item={item}/></div></div></main><Footer/></>
}

function BookingCard({item}) {
  const [date,setDate]=useState('')
  const [guests,setGuests]=useState(2)
  const [message,setMessage]=useState('')
  const [busy,setBusy]=useState(false)
  const book=async()=>{
    if(!localStorage.getItem('travel_token')){window.location.href='/login';return}
    if(!date){setMessage('Please choose your travel date.');return}
    setBusy(true);setMessage('')
    try{await api.post('/bookings',{destination:item._id,travelDate:date,guests});setMessage('Your booking request has been received! View it in My trips.')}
    catch(e){setMessage(e.response?.data?.message || 'Could not create booking. Please try again.')}
    finally{setBusy(false)}
  }
  return <aside className="booking-card"><span className="booking-kicker">YOUR JOURNEY, YOUR WAY</span><div className="booking-price"> ${item.price.toLocaleString()} <small>/ person</small></div><p>Estimated package price</p><label>Travel date<input type="date" min={new Date().toISOString().slice(0,10)} value={date} onChange={e=>setDate(e.target.value)}/></label><label>Travelers<div className="counter"><button onClick={()=>setGuests(Math.max(1,guests-1))}>−</button><b>{guests}</b><button onClick={()=>setGuests(Math.min(12,guests+1))}>+</button></div></label><div className="booking-total"><span>Estimated total</span><b>${(item.price*guests).toLocaleString()}</b></div><button className="primary-btn full" disabled={busy} onClick={book}>{busy?'Sending...':'Request to book'} <ArrowRight size={16}/></button>{message&&<p className="form-message">{message}</p>}<small className="secure-note"><ShieldCheck size={13}/> No payment is taken at this stage.</small></aside>
}

function Auth({mode}) {
  const [form,setForm]=useState({name:'',email:'',password:''})
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  const navigate=useNavigate()
  const submit=async e=>{e.preventDefault();setBusy(true);setError('');try{const {data}=await api.post(`/auth/${mode}`,form);localStorage.setItem('travel_token',data.token);localStorage.setItem('travel_user',JSON.stringify(data.user));navigate('/bookings')}catch(err){setError(err.response?.data?.message||'Something went wrong. Check that the server is running.')}finally{setBusy(false)}}
  return <main className="auth-page"><div className="auth-image"><div><span className="eyebrow light"><span></span> THE WORLD IS WAITING</span><h2>Some journeys<br/>change <em>everything.</em></h2></div></div><div className="auth-form-wrap"><form className="auth-form" onSubmit={submit}><Link to="/" className="back-link">← Back home</Link><div className="eyebrow"><span></span> {mode==='login'?'WELCOME BACK':'START SOMEWHERE'}</div><h1>{mode==='login'?'Good to see you.':'Your next story awaits.'}</h1><p>{mode==='login'?'Log in to pick up where your travels left off.':'Create an account and let the good journeys begin.'}</p>{mode==='register'&&<label>Your name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Full name"/></label>}<label>Email address<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label><label>Password<input required type="password" minLength="6" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="At least 6 characters"/></label>{error&&<p className="error-text">{error}</p>}<button className="primary-btn full" disabled={busy}>{busy?'Please wait...':mode==='login'?'Log in':'Create account'} <ArrowRight size={16}/></button><p className="auth-switch">{mode==='login'?"New around here?":'Already have an account?'} <Link to={mode==='login'?'/register':'/login'}>{mode==='login'?'Create an account':'Log in'}</Link></p></form></div></main>
}

function MyBookings() {
  const [items,setItems]=useState([])
  const [error,setError]=useState('')
  const user=JSON.parse(localStorage.getItem('travel_user')||'null')
  useEffect(()=>{api.get('/bookings/my').then(r=>setItems(r.data)).catch(e=>setError(e.response?.data?.message||'Please log in to view your trips.'))},[])
  return <><main className="page-main"><div className="container"><div className="eyebrow"><span></span> YOUR TRAVEL JOURNAL</div><h1 className="page-title">Hello, {user?.name?.split(' ')[0]||'traveler'}.</h1><p className="page-lead">Every great story starts with a somewhere.</p>{error&&<p className="error-text">{error} <Link to="/login">Log in</Link></p>}{items.length===0&&!error&&<div className="empty-state"><Compass size={34}/><h3>No trips just yet.</h3><p>Your next adventure is waiting to be found.</p><Link className="primary-btn" to="/destinations">Explore destinations <ArrowRight size={15}/></Link></div>}<div className="booking-list">{items.map(b=><div className="booking-row" key={b._id}><div><b>{b.destination?.name||'Your destination'}</b><span>{new Date(b.travelDate).toLocaleDateString()} · {b.guests} travelers</span></div><span className={`status status-${b.status}`}>{b.status}</span><strong>${b.totalPrice?.toLocaleString()}</strong></div>)}</div></div></main><Footer/></>
}

export default function App() {
  return <><Header/><Routes><Route path="/" element={<Home/>}/><Route path="/destinations" element={<Destinations/>}/><Route path="/destinations/:id" element={<DestinationDetail/>}/><Route path="/login" element={<Auth mode="login"/>}/><Route path="/register" element={<Auth mode="register"/>}/><Route path="/bookings" element={<MyBookings/>}/><Route path="*" element={<main className="page-main container"><h1>Page not found</h1><Link to="/">Return home</Link></main>}/></Routes></>
}
