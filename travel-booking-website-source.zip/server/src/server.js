import express from 'express'
import mongoose from 'mongoose'
import cors from 'cors'
import dotenv from 'dotenv'
import authRoutes from './routes/auth.js'
import destinationRoutes from './routes/destinations.js'
import bookingRoutes from './routes/bookings.js'
dotenv.config()
const app=express()
app.use(cors({origin:process.env.CLIENT_URL || 'http://localhost:5173'}))
app.use(express.json())
app.get('/api/health',(req,res)=>res.json({status:'ok',message:'Travel API is running'}))
app.use('/api/auth',authRoutes)
app.use('/api/destinations',destinationRoutes)
app.use('/api/bookings',bookingRoutes)
app.use((err,req,res,next)=>{console.error(err);res.status(err.status||500).json({message:err.message||'Server error'})})
const start=async()=>{
  try{
    await mongoose.connect(process.env.MONGO_URI)
    const port=process.env.PORT||5000
    app.listen(port,()=>console.log(`Travel API listening on ${port}`))
  }catch(err){console.error('Database connection failed:',err.message);process.exit(1)}
}
start()
