import {Router} from 'express'
import Booking from '../models/Booking.js'
import Destination from '../models/Destination.js'
import {protect,adminOnly} from '../middleware/auth.js'
const router=Router()
router.post('/',protect,async(req,res,next)=>{
  try{
    const {destination,travelDate,guests}=req.body
    const count=Number(guests)
    if(!destination||!travelDate||!Number.isInteger(count)||count<1||count>12) return res.status(400).json({message:'Choose a destination, valid date and 1–12 travelers.'})
    const date=new Date(travelDate)
    if(Number.isNaN(date.getTime())||date<new Date(new Date().toDateString())) return res.status(400).json({message:'Travel date must be today or later.'})
    const place=await Destination.findById(destination)
    if(!place)return res.status(404).json({message:'Destination not found.'})
    const booking=await Booking.create({user:req.user._id,destination,travelDate:date,guests:count,totalPrice:place.price*count})
    res.status(201).json(await booking.populate('destination'))
  }catch(e){next(e)}
})
router.get('/my',protect,async(req,res,next)=>{
  try{res.json(await Booking.find({user:req.user._id}).populate('destination').sort({createdAt:-1}))}catch(e){next(e)}
})
router.get('/',protect,adminOnly,async(req,res,next)=>{
  try{res.json(await Booking.find().populate('destination user','name email').sort({createdAt:-1}))}catch(e){next(e)}
})
router.patch('/:id/status',protect,adminOnly,async(req,res,next)=>{
  try{
    const {status}=req.body
    if(!['pending','confirmed','cancelled'].includes(status))return res.status(400).json({message:'Invalid booking status.'})
    const booking=await Booking.findByIdAndUpdate(req.params.id,{status},{new:true}).populate('destination user','name email')
    if(!booking)return res.status(404).json({message:'Booking not found.'})
    res.json(booking)
  }catch(e){next(e)}
})
export default router
