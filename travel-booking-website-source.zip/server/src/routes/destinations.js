import {Router} from 'express'
import Destination from '../models/Destination.js'
import {protect,adminOnly} from '../middleware/auth.js'
const router=Router()
const demo=[
 {name:'Bali',country:'Indonesia',category:'Island escape',price:899,rating:4.9,days:6,image:'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1200&q=85',description:'Slow mornings, emerald rice terraces and sunsets that make you forget to check the time.',featured:true},
 {name:'Amalfi Coast',country:'Italy',category:'Coastal charm',price:1299,rating:4.8,days:5,image:'https://images.unsplash.com/photo-1533587851505-d119e13fa0d7?auto=format&fit=crop&w=1200&q=85',description:'Pastel villages, winding coastal roads and long lunches overlooking the Mediterranean.'},
 {name:'Kyoto',country:'Japan',category:'Culture & calm',price:1099,rating:4.9,days:7,image:'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=85',description:'Find quiet beauty in lantern-lit lanes, timeless temples and peaceful gardens.'},
 {name:'Santorini',country:'Greece',category:'Romantic retreat',price:1149,rating:4.8,days:5,image:'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1200&q=85',description:'Whitewashed architecture, blue domes and impossibly beautiful Aegean views.'},
 {name:'Swiss Alps',country:'Switzerland',category:'Mountain air',price:1499,rating:5,days:6,image:'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1200&q=85',description:'A breath of alpine air, scenic rail journeys and postcard-perfect mountain towns.'}
]
router.get('/',async(req,res,next)=>{
  try{
    let items=await Destination.find().sort({featured:-1,createdAt:-1})
    if(!items.length) items=await Destination.insertMany(demo)
    res.json(items)
  }catch(e){next(e)}
})
router.get('/:id',async(req,res,next)=>{
  try{const item=await Destination.findById(req.params.id);if(!item)return res.status(404).json({message:'Destination not found'});res.json(item)}catch(e){next(e)}
})
router.post('/',protect,adminOnly,async(req,res,next)=>{try{res.status(201).json(await Destination.create(req.body))}catch(e){next(e)}})
router.put('/:id',protect,adminOnly,async(req,res,next)=>{try{const item=await Destination.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!item)return res.status(404).json({message:'Destination not found'});res.json(item)}catch(e){next(e)}})
router.delete('/:id',protect,adminOnly,async(req,res,next)=>{try{const item=await Destination.findByIdAndDelete(req.params.id);if(!item)return res.status(404).json({message:'Destination not found'});res.json({message:'Destination deleted'})}catch(e){next(e)}})
export default router
