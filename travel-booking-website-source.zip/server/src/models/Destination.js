import mongoose from 'mongoose'
const destinationSchema=new mongoose.Schema({
  name:{type:String,required:true,trim:true},
  country:{type:String,required:true},
  category:{type:String,default:'Curated escape'},
  price:{type:Number,required:true,min:0},
  rating:{type:Number,default:4.8},
  days:{type:Number,default:5},
  image:{type:String,required:true},
  description:{type:String,default:''},
  featured:{type:Boolean,default:false}
},{timestamps:true})
export default mongoose.model('Destination',destinationSchema)
