import mongoose from 'mongoose'
const bookingSchema=new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
  destination:{type:mongoose.Schema.Types.ObjectId,ref:'Destination',required:true},
  travelDate:{type:Date,required:true},
  guests:{type:Number,required:true,min:1,max:12},
  totalPrice:{type:Number,required:true,min:0},
  status:{type:String,enum:['pending','confirmed','cancelled'],default:'pending'}
},{timestamps:true})
export default mongoose.model('Booking',bookingSchema)
