import jwt from 'jsonwebtoken'
import User from '../models/User.js'
export const protect=async(req,res,next)=>{
  try{
    const header=req.headers.authorization
    if(!header?.startsWith('Bearer ')) return res.status(401).json({message:'Please log in to continue.'})
    const decoded=jwt.verify(header.split(' ')[1],process.env.JWT_SECRET)
    req.user=await User.findById(decoded.id).select('-password')
    if(!req.user) return res.status(401).json({message:'Account not found.'})
    next()
  }catch{return res.status(401).json({message:'Invalid or expired session.'})}
}
export const adminOnly=(req,res,next)=>{
  if(req.user?.role!=='admin') return res.status(403).json({message:'Admin access required.'})
  next()
}
